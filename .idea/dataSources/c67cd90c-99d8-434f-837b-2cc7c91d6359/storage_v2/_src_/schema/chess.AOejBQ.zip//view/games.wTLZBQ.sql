create definer = root@localhost view games as
select `chess`.`gamedata`.`id`            AS `id`,
       `chess`.`gamedata`.`gameName`      AS `gameName`,
       `chess`.`gamedata`.`whiteUsername` AS `whiteUsername`,
       `chess`.`gamedata`.`blackUsername` AS `blackUsername`,
       `chess`.`gamedata`.`json`          AS `json`
from `chess`.`gamedata`;

